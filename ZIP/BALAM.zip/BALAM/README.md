# BALAM 🔐

Gestor de contraseñas en consola escrito en C++17. Guarda tus credenciales en un archivo local **cifrado con AES-256**, protegido por una contraseña maestra que **nunca se almacena**.

Proyecto del **Grup 11** desarrollado con **Scrum** en 3 sprints de una semana.

| Rol | Persona |
|---|---|
| Scrum Master / Developer | Davor Blaz |
| Developer | Camilly Aoki |
| Developer | Gerard Conesa |
| Product Owner | Professor |

---

## Funcionalidades

- Menú interactivo en consola, en **español, catalán, inglés y noruego**
- Creación y verificación de la **contraseña maestra** (máx. 3 intentos)
- **Añadir, ver, buscar, modificar y eliminar** entradas (servicio, usuario, contraseña)
- **Generador** de contraseñas seguras con longitud y tipos de caracteres configurables
- **Bloqueo** de la bóveda sin cerrar el programa
- Control de errores: opciones inválidas, campos vacíos, archivo dañado o manipulado, fin de entrada

## Estructura del proyecto

```
BALAM/
├── CMakeLists.txt
├── README.md
└── src/
    ├── main.cpp       Punto de entrada y captura de errores
    ├── app.cpp/.hpp   Menús y acciones del usuario
    ├── auth.cpp/.hpp  Crear y verificar la contraseña maestra
    ├── console.cpp/.hpp  Entrada/salida y validación de datos
    ├── crypto.cpp/.hpp   SHA-256, HMAC, PBKDF2, AES-256-CTR, aleatoriedad, generador
    ├── i18n.cpp/.hpp  Traducciones (es / ca / en / no)
    └── vault.cpp/.hpp Bóveda cifrada: guardar, cargar y bloquear
```

No necesita librerías externas: toda la criptografía está implementada en `crypto.cpp` y comprobada con los vectores de prueba oficiales (FIPS 180-4, FIPS-197).

## Compilar y ejecutar

### Visual Studio 2019/2022
1. *Archivo → Abrir → Carpeta…* y selecciona la carpeta `BALAM` (Visual Studio detecta el `CMakeLists.txt`).
2. Elige `balam.exe` como elemento de inicio y pulsa ▶.

### CMake (Windows, Linux o macOS)
```bash
cmake -S . -B build
cmake --build build --config Release
./build/balam            # en Windows: build\Release\balam.exe
```

### Sin CMake (g++)
```bash
g++ -std=c++17 -O2 -Isrc src/*.cpp -o balam
```

La bóveda se guarda en `balam.dat`, en la carpeta desde la que se ejecuta el programa.

## Seguridad

| Aspecto | Solución |
|---|---|
| Contraseña maestra | No se guarda. Se deriva con **PBKDF2-HMAC-SHA256** (100.000 iteraciones, sal aleatoria de 16 bytes) y solo se guarda un verificador |
| Cifrado de las entradas | **AES-256 en modo CTR**, con un IV aleatorio nuevo en cada guardado |
| Integridad del archivo | **HMAC-SHA256** sobre todo el archivo: cualquier modificación se detecta |
| Aleatoriedad | `BCryptGenRandom` (Windows) / `/dev/urandom` (Linux, macOS) |
| Memoria | Las claves y los datos descifrados se borran al bloquear o salir |
| Escritura | Atómica (archivo temporal + reemplazo): un fallo no corrompe la bóveda |
| Fuerza bruta | Máximo 3 intentos y retardo tras cada contraseña incorrecta |

Formato de `balam.dat`:
```
"BALAM"+versión | sal(16) | iteraciones(4) | verificador(32) | IV(16) | longitud(4) | datos cifrados | HMAC(32)
```

## Planificación Scrum

| Sprint | Fechas | Historias de usuario |
|---|---|---|
| **Sprint 1** | 15/10 – 21/10 | HU1 Menú · HU2 Idiomas · HU3 Crear contraseña maestra · HU4 Verificarla · HU5 Opciones incorrectas |
| **Sprint 2** | 22/10 – 28/10 | HU6 Añadir entradas · HU7 Guardado cifrado · HU8 Consultar · HU9 Buscar |
| **Sprint 3** | 29/10 – 04/11 | HU10 Modificar · HU11 Eliminar · HU12 Generador · HU13 Gestión de errores · HU14 Bloqueo |

Cada archivo del código indica en sus comentarios la historia de usuario, el sprint y el responsable de cada parte.

### Definition of Done
1. La funcionalidad funciona correctamente y se puede demostrar.
2. Cumple todos los criterios de aceptación de la historia de usuario.
3. Ha sido probada por un miembro diferente de quien la ha desarrollado.
4. No presenta errores críticos conocidos y los datos sensibles se tratan de manera segura.
5. El código está guardado y la tarea está actualizada en el Excel de seguimiento.
