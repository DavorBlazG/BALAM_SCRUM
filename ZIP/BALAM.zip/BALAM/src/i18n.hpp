// =============================================================================
//  i18n.hpp - Idiomas de BALAM: español, catalán, inglés y noruego
//
//  [HU2 - Sprint 1] Selección de idiomas (Gerard Conesa)
//                   Traducción de los mensajes (Camilly Aoki)
//                   Integración con los menús (Gerard Conesa)
// =============================================================================
#pragma once

enum Lang { LANG_ES = 0, LANG_CA, LANG_EN, LANG_NO, LANG_COUNT };

// Identificadores de todos los textos del programa
enum Msg {
    M_OPTION, M_INVALID_OPTION, M_RANGE_A, M_RANGE_AND, M_YES_NO, M_YES_CHAR,
    M_NEW_VAULT, M_MASTER_RULES, M_MASTER_NEW, M_MASTER_CONFIRM, M_MASTER_MISMATCH,
    M_MASTER_TOO_SHORT, M_MASTER_CREATED, M_MASTER_ENTER, M_MASTER_WRONG,
    M_TOO_MANY_TRIES, M_UNLOCKED, M_PROCESSING,
    M_MENU_TITLE, M_MENU_ADD, M_MENU_LIST, M_MENU_SEARCH, M_MENU_EDIT, M_MENU_DELETE,
    M_MENU_GEN, M_MENU_LANG, M_MENU_LOCK, M_MENU_EXIT,
    M_SERVICE, M_USER, M_PASSWORD, M_FIELD_EMPTY, M_ASK_GENERATE, M_ENTRY_ADDED,
    M_NO_ENTRIES, M_SHOW_PASS_WHICH, M_SEARCH_TERM, M_SEARCH_NONE,
    M_EDIT_WHICH, M_EDIT_KEEP, M_CURRENT, M_ASK_CHANGE_PASS, M_ENTRY_UPDATED,
    M_DELETE_WHICH, M_DELETE_CONFIRM, M_ENTRY_DELETED, M_CANCELLED,
    M_GEN_LENGTH, M_GEN_LOWER, M_GEN_UPPER, M_GEN_DIGITS, M_GEN_SYMBOLS,
    M_GEN_NOTYPE, M_GEN_RESULT,
    M_LOCKED, M_LOCKED_TITLE, M_MENU_UNLOCK, M_LANG_CHANGED, M_BYE,
    M_ERR_SAVE, M_ERR_READ, M_ERR_CORRUPT, M_ERR_RANDOM, M_ERR_UNEXPECTED, M_INPUT_CLOSED,
    M_COUNT
};

void        setLanguage(Lang lang);
Lang        getLanguage();
const char* T(Msg m);          // texto del mensaje en el idioma actual
