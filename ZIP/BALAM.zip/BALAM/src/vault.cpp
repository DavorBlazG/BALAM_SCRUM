// =============================================================================
//  vault.cpp - Implementación de la bóveda cifrada
// =============================================================================
#include "vault.hpp"

#ifdef _WIN32
#  ifndef NOMINMAX
#    define NOMINMAX
#  endif
#  include <windows.h>
#endif

#include <cstdio>
#include <cstring>
#include <fstream>

using namespace std;

static const char   MAGIC[6]  = { 'B', 'A', 'L', 'A', 'M', 1 };
static const size_t MAGIC_LEN = sizeof(MAGIC);

// ---- Serialización (little-endian, cadenas con prefijo de longitud) ----------
static void putU32(Bytes& b, uint32_t v) {
    for (int i = 0; i < 4; ++i) b.push_back(static_cast<uint8_t>(v >> (8 * i)));
}
static uint32_t getU32(const uint8_t* p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static void putString(Bytes& b, const string& s) {
    putU32(b, static_cast<uint32_t>(s.size()));
    b.insert(b.end(), s.begin(), s.end());
}
static bool readString(const Bytes& b, size_t& pos, string& out) {
    if (pos + 4 > b.size()) return false;
    uint32_t len = getU32(&b[pos]); pos += 4;
    if (len > b.size() - pos) return false;
    out.assign(reinterpret_cast<const char*>(b.data()) + pos, len);
    pos += len;
    return true;
}

// =============================================================================
Boveda::Boveda(const string& filePath)
    : path(filePath), iterations(PBKDF2_ITERATIONS), unlocked(false) {}

Boveda::~Boveda() { lock(); }

bool Boveda::exists() const {
    ifstream f(path.c_str(), ios::binary);
    return f.good();
}

// HU3: crear la contraseña maestra -> solo se guarda el verificador.
Boveda::Result Boveda::create(const string& master) {
    secureRandom(salt.data(), salt.size());
    iterations = PBKDF2_ITERATIONS;
    deriveKeys(master, verifier.data());
    items.clear();
    unlocked = true;
    if (!save()) { lock(); return IO_ERROR; }
    return OK;
}

// HU4 + HU7: verificar la contraseña maestra y descifrar la bóveda.
Boveda::Result Boveda::unlock(const string& master) {
    Bytes file;
    if (!readFile(file)) return IO_ERROR;

    const size_t headerLen = MAGIC_LEN + 16 + 4 + 32;
    const size_t minLen = headerLen + 16 + 4 + 32;
    if (file.size() < minLen || memcmp(file.data(), MAGIC, MAGIC_LEN) != 0) return CORRUPT;

    size_t pos = MAGIC_LEN;
    memcpy(salt.data(), &file[pos], 16); pos += 16;
    iterations = getU32(&file[pos]);      pos += 4;
    if (iterations == 0 || iterations > 10000000) return CORRUPT;
    array<uint8_t, 32> storedVerifier;
    memcpy(storedVerifier.data(), &file[pos], 32); pos += 32;

    uint8_t candidate[32];
    deriveKeys(master, candidate);
    bool okPass = constantTimeEqual(candidate, storedVerifier.data(), 32);
    secureWipe(candidate, 32);
    if (!okPass) { wipeKeys(); return WRONG_PASSWORD; }

    // Integridad del archivo (HMAC)
    size_t macPos = file.size() - 32;
    uint8_t mac[32];
    hmacSha256(macKey.data(), 32, file.data(), macPos, mac);
    if (!constantTimeEqual(mac, &file[macPos], 32)) { wipeKeys(); return CORRUPT; }

    uint8_t iv[16];
    memcpy(iv, &file[pos], 16); pos += 16;
    uint32_t ctLen = getU32(&file[pos]); pos += 4;
    if (pos + ctLen != macPos) { wipeKeys(); return CORRUPT; }

    Bytes plain(ctLen);
    if (ctLen > 0) {
        Aes256 aes(encKey.data());
        aes.ctr(iv, &file[pos], plain.data(), ctLen);
    }
    vector<Entrada> loaded;
    bool okParse = deserialize(plain, loaded);
    secureWipe(plain);
    if (!okParse) { wipeKeys(); return CORRUPT; }

    memcpy(verifier.data(), storedVerifier.data(), 32);
    items.swap(loaded);
    unlocked = true;
    return OK;
}

// HU7: guardar todas las entradas cifradas (con IV nuevo en cada guardado).
bool Boveda::save() {
    if (!unlocked) return false;
    try {
        Bytes plain = serialize(items);
        uint8_t iv[16];
        secureRandom(iv, 16);
        Bytes ct(plain.size());
        if (!plain.empty()) {
            Aes256 aes(encKey.data());
            aes.ctr(iv, plain.data(), ct.data(), plain.size());
        }
        secureWipe(plain);

        Bytes out;
        out.insert(out.end(), MAGIC, MAGIC + MAGIC_LEN);
        out.insert(out.end(), salt.begin(), salt.end());
        putU32(out, iterations);
        out.insert(out.end(), verifier.begin(), verifier.end());
        out.insert(out.end(), iv, iv + 16);
        putU32(out, static_cast<uint32_t>(ct.size()));
        out.insert(out.end(), ct.begin(), ct.end());
        uint8_t mac[32];
        hmacSha256(macKey.data(), 32, out.data(), out.size(), mac);
        out.insert(out.end(), mac, mac + 32);

        return writeFileAtomic(out);
    } catch (...) {
        return false;
    }
}

// HU14: bloquear -> borra claves y datos descifrados de la memoria.
void Boveda::lock() {
    for (size_t i = 0; i < items.size(); ++i) {
        secureWipe(items[i].servicio);
        secureWipe(items[i].usuario);
        secureWipe(items[i].contrasena);
    }
    items.clear();
    wipeKeys();
    unlocked = false;
}

// PBKDF2 -> clave maestra derivada; de ella salen 3 claves independientes.
void Boveda::deriveKeys(const string& master, uint8_t outVerifier[32]) {
    uint8_t dk[32];
    pbkdf2Sha256(master, salt.data(), salt.size(), iterations, dk);
    static const char ENC[] = "BALAM-enc", MACL[] = "BALAM-mac", VER[] = "BALAM-verify";
    hmacSha256(dk, 32, reinterpret_cast<const uint8_t*>(ENC), sizeof(ENC) - 1, encKey.data());
    hmacSha256(dk, 32, reinterpret_cast<const uint8_t*>(MACL), sizeof(MACL) - 1, macKey.data());
    hmacSha256(dk, 32, reinterpret_cast<const uint8_t*>(VER), sizeof(VER) - 1, outVerifier);
    secureWipe(dk, 32);
}

void Boveda::wipeKeys() {
    secureWipe(encKey.data(), encKey.size());
    secureWipe(macKey.data(), macKey.size());
}

Bytes Boveda::serialize(const vector<Entrada>& v) {
    Bytes b;
    putU32(b, static_cast<uint32_t>(v.size()));
    for (size_t i = 0; i < v.size(); ++i) {
        putString(b, v[i].servicio);
        putString(b, v[i].usuario);
        putString(b, v[i].contrasena);
    }
    return b;
}

bool Boveda::deserialize(const Bytes& b, vector<Entrada>& out) {
    out.clear();
    if (b.size() < 4) return false;
    size_t pos = 0;
    uint32_t count = getU32(&b[0]); pos += 4;
    if (count > b.size()) return false;
    for (uint32_t i = 0; i < count; ++i) {
        Entrada e;
        if (!readString(b, pos, e.servicio) || !readString(b, pos, e.usuario) ||
            !readString(b, pos, e.contrasena)) return false;
        out.push_back(e);
    }
    return pos == b.size();
}

bool Boveda::readFile(Bytes& out) const {
    ifstream f(path.c_str(), ios::binary);
    if (!f) return false;
    f.seekg(0, ios::end);
    streamoff size = f.tellg();
    if (size < 0 || size > 64 * 1024 * 1024) return false;
    f.seekg(0, ios::beg);
    out.resize(static_cast<size_t>(size));
    if (size > 0 && !f.read(reinterpret_cast<char*>(out.data()), size)) return false;
    return true;
}

// HU13: escribe primero en un temporal y luego lo reemplaza; si falla a medias,
// el archivo original queda intacto.
bool Boveda::writeFileAtomic(const Bytes& data) const {
    string tmp = path + ".tmp";
    {
        ofstream f(tmp.c_str(), ios::binary | ios::trunc);
        if (!f) return false;
        f.write(reinterpret_cast<const char*>(data.data()), static_cast<streamsize>(data.size()));
        f.flush();
        if (!f) { f.close(); remove(tmp.c_str()); return false; }
    }
#ifdef _WIN32
    if (!MoveFileExA(tmp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        remove(tmp.c_str());
        return false;
    }
#else
    if (rename(tmp.c_str(), path.c_str()) != 0) { remove(tmp.c_str()); return false; }
#endif
    return true;
}
