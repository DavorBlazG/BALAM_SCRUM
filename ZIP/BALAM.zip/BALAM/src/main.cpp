// =============================================================================
//  BALAM - Gestor de contraseñas en consola (C++17)
//  Versión 1.0 - Grup 11
//    Davor Blaz (Scrum Master / Developer), Camilly Aoki (Developer),
//    Gerard Conesa (Developer). Product Owner: Professor.
//
//  main.cpp: punto de entrada. Prepara la consola, ejecuta la aplicación y
//  captura cualquier error para que BALAM no se cierre de forma inesperada.
//  [HU13 - Sprint 3] Gestión de errores (Gerard Conesa)
// =============================================================================
#include "app.hpp"
#include "console.hpp"
#include "i18n.hpp"

#include <iostream>
#include <stdexcept>
#include <string>

using namespace std;

int main() {
    setupConsole();
    try {
        return runApp();
    } catch (const InputClosed&) {
        cout << "\n  " << T(M_INPUT_CLOSED) << endl;
        return 0;
    } catch (const runtime_error& e) {
        if (string(e.what()) == "RNG") cout << "\n  [!] " << T(M_ERR_RANDOM) << endl;
        else cout << "\n  [!] " << T(M_ERR_UNEXPECTED) << e.what() << endl;
        return 1;
    } catch (const exception& e) {
        cout << "\n  [!] " << T(M_ERR_UNEXPECTED) << e.what() << endl;
        return 1;
    } catch (...) {
        cout << "\n  [!] " << T(M_ERR_UNEXPECTED) << "?" << endl;
        return 1;
    }
}
