// =============================================================================
//  app.cpp - Menús y acciones de BALAM
// =============================================================================
#include "app.hpp"
#include "auth.hpp"
#include "console.hpp"
#include "crypto.hpp"
#include "i18n.hpp"
#include "vault.hpp"

#include <algorithm>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

static const char* VAULT_FILE      = "balam.dat";
static const int   GEN_MIN_LEN     = 8;
static const int   GEN_MAX_LEN     = 128;
static const int   GEN_DEFAULT_LEN = 16;

// =============================================================================
//  Pantallas
//  [HU1 - Sprint 1] Menú principal en consola, diseño (Davor Blaz)
//  [HU2 - Sprint 1] Selección de idioma (Gerard Conesa)
// =============================================================================
static void printBanner() {
    cout << "\n"
         << "  ================================================\n"
         << "     ____    _    _        _    __  __\n"
         << "    | __ )  / \\  | |      / \\  |  \\/  |\n"
         << "    |  _ \\ / _ \\ | |     / _ \\ | |\\/| |\n"
         << "    | |_) / ___ \\| |___ / ___ \\| |  | |\n"
         << "    |____/_/   \\_\\_____/_/   \\_\\_|  |_|\n"
         << "\n"
         << "  ================================================\n";
}

static void chooseLanguage() {
    cout << "\n  Idioma / Idioma / Language / Språk\n"
         << "   1. Español\n   2. Català\n   3. English\n   4. Norsk\n";
    for (;;) {
        long v;
        if (parseInt(prompt("  > "), v) && v >= 1 && v <= 4) { setLanguage(static_cast<Lang>(v - 1)); return; }
        cout << "  [!] 1-4" << endl;
    }
}

static int mainMenu(size_t numEntries) {
    printTitle(string(T(M_MENU_TITLE)) + "  (" + to_string(numEntries) + ")");
    cout << "   1. " << T(M_MENU_ADD)    << "\n"
         << "   2. " << T(M_MENU_LIST)   << "\n"
         << "   3. " << T(M_MENU_SEARCH) << "\n"
         << "   4. " << T(M_MENU_EDIT)   << "\n"
         << "   5. " << T(M_MENU_DELETE) << "\n"
         << "   6. " << T(M_MENU_GEN)    << "\n"
         << "   7. " << T(M_MENU_LANG)   << "\n"
         << "   8. " << T(M_MENU_LOCK)   << "\n"
         << "   0. " << T(M_MENU_EXIT)   << "\n";
    return readMenuOption(0, 8);
}

static int lockedMenu() {
    printTitle(T(M_LOCKED_TITLE));
    cout << "   1. " << T(M_MENU_UNLOCK) << "\n"
         << "   2. " << T(M_MENU_LANG)   << "\n"
         << "   0. " << T(M_MENU_EXIT)   << "\n";
    return readMenuOption(0, 2);
}

// =============================================================================
//  Generador interactivo
//  [HU12 - Sprint 3] Configurar longitud y tipos de caracteres (Camilly Aoki)
// =============================================================================
static string generatorDialog() {
    ostringstream lenPrompt;
    lenPrompt << "  " << T(M_GEN_LENGTH) << " (" << GEN_MIN_LEN << "-" << GEN_MAX_LEN << ") ["
              << GEN_DEFAULT_LEN << "]: ";
    int len = readNumber(lenPrompt.str(), GEN_MIN_LEN, GEN_MAX_LEN, GEN_DEFAULT_LEN);
    for (;;) {
        bool lo = readYesNo(string("  ") + T(M_GEN_LOWER));
        bool up = readYesNo(string("  ") + T(M_GEN_UPPER));
        bool di = readYesNo(string("  ") + T(M_GEN_DIGITS));
        bool sy = readYesNo(string("  ") + T(M_GEN_SYMBOLS));
        if (lo || up || di || sy) return generatePassword(len, lo, up, di, sy);
        cout << "  [!] " << T(M_GEN_NOTYPE) << endl;
    }
}

// Pide la contraseña de una entrada: generada o escrita a mano.
static string askEntryPassword() {
    if (readYesNo(string("  ") + T(M_ASK_GENERATE))) {
        string p = generatorDialog();
        cout << "  " << T(M_GEN_RESULT) << p << endl;
        return p;
    }
    return readNonEmptyHidden(T(M_PASSWORD));
}

// =============================================================================
//  Lista de entradas
//  [HU8 - Sprint 2] Mostrar las entradas en formato tabla (Camilly Aoki)
// =============================================================================
static vector<size_t> allIndices(const vector<Entrada>& e) {
    vector<size_t> idx;
    for (size_t i = 0; i < e.size(); ++i) idx.push_back(i);
    return idx;
}

static void printEntries(const vector<Entrada>& e, const vector<size_t>& idx) {
    cout << "\n  " << left << setw(5) << "#" << setw(26) << T(M_SERVICE) << T(M_USER) << "\n"
         << "  " << string(55, '-') << "\n";
    for (size_t k = 0; k < idx.size(); ++k) {
        const Entrada& x = e[idx[k]];
        string srv = x.servicio.size() > 24 ? x.servicio.substr(0, 23) + "~" : x.servicio;
        cout << "  " << left << setw(5) << (idx[k] + 1) << setw(26) << srv << x.usuario << "\n";
    }
    cout << "  " << string(55, '-') << "\n" << right;
}

// Permite consultar la contraseña de una de las entradas listadas.
static void browsePasswords(const vector<Entrada>& e, const vector<size_t>& idx) {
    for (;;) {
        int n = readNumber(string("  ") + T(M_SHOW_PASS_WHICH), 0, static_cast<int>(e.size()));
        if (n == 0) return;
        if (find(idx.begin(), idx.end(), static_cast<size_t>(n - 1)) == idx.end()) {
            cout << "  [!] " << T(M_INVALID_OPTION) << endl;
            continue;
        }
        const Entrada& x = e[n - 1];
        cout << "  " << x.servicio << " | " << x.usuario << " | " << T(M_PASSWORD) << ": " << x.contrasena << endl;
    }
}

// =============================================================================
//  Acciones del menú
// =============================================================================

// [HU6 - Sprint 2] Añadir entrada (Gerard Conesa)
static void actionAdd(Boveda& v) {
    printTitle(T(M_MENU_ADD));
    Entrada e;
    e.servicio = readNonEmpty(T(M_SERVICE));
    e.usuario = readNonEmpty(T(M_USER));
    e.contrasena = askEntryPassword();
    v.entradas().push_back(e);
    if (v.save()) cout << "  " << T(M_ENTRY_ADDED) << endl;
    else { v.entradas().pop_back(); cout << "  [!] " << T(M_ERR_SAVE) << endl; }
    secureWipe(e.contrasena);
}

// [HU8 - Sprint 2] Ver entradas (Gerard Conesa / Camilly Aoki)
static void actionList(Boveda& v) {
    printTitle(T(M_MENU_LIST));
    const vector<Entrada>& e = v.entradas();
    if (e.empty()) { cout << "  " << T(M_NO_ENTRIES) << endl; return; }
    vector<size_t> idx = allIndices(e);
    printEntries(e, idx);
    browsePasswords(e, idx);
}

// [HU9 - Sprint 2] Buscar por nombre del servicio (Camilly Aoki)
static void actionSearch(Boveda& v) {
    printTitle(T(M_MENU_SEARCH));
    const vector<Entrada>& e = v.entradas();
    if (e.empty()) { cout << "  " << T(M_NO_ENTRIES) << endl; return; }
    string term = toLower(readNonEmpty(T(M_SEARCH_TERM)));
    vector<size_t> idx;
    for (size_t i = 0; i < e.size(); ++i)
        if (toLower(e[i].servicio).find(term) != string::npos) idx.push_back(i);
    if (idx.empty()) { cout << "  " << T(M_SEARCH_NONE) << endl; return; }
    printEntries(e, idx);
    browsePasswords(e, idx);
}

// [HU10 - Sprint 3] Modificar entrada y guardar en el archivo cifrado (Davor Blaz)
static void actionEdit(Boveda& v) {
    printTitle(T(M_MENU_EDIT));
    vector<Entrada>& e = v.entradas();
    if (e.empty()) { cout << "  " << T(M_NO_ENTRIES) << endl; return; }
    printEntries(e, allIndices(e));

    int n = readNumber(string("  ") + T(M_EDIT_WHICH), 0, static_cast<int>(e.size()));
    if (n == 0) { cout << "  " << T(M_CANCELLED) << endl; return; }

    Entrada backup = e[n - 1];
    Entrada& x = e[n - 1];
    cout << "  " << T(M_EDIT_KEEP) << endl;
    string s = trim(prompt("  " + string(T(M_SERVICE)) + " [" + T(M_CURRENT) + ": " + x.servicio + "]: "));
    if (!s.empty()) x.servicio = s;
    string u = trim(prompt("  " + string(T(M_USER)) + " [" + T(M_CURRENT) + ": " + x.usuario + "]: "));
    if (!u.empty()) x.usuario = u;
    if (readYesNo(string("  ") + T(M_ASK_CHANGE_PASS))) x.contrasena = askEntryPassword();

    if (v.save()) cout << "  " << T(M_ENTRY_UPDATED) << endl;
    else { x = backup; cout << "  [!] " << T(M_ERR_SAVE) << endl; }
    secureWipe(backup.contrasena);
}

// [HU11 - Sprint 3] Eliminar con confirmación y actualizar el archivo (Gerard Conesa)
static void actionDelete(Boveda& v) {
    printTitle(T(M_MENU_DELETE));
    vector<Entrada>& e = v.entradas();
    if (e.empty()) { cout << "  " << T(M_NO_ENTRIES) << endl; return; }
    printEntries(e, allIndices(e));

    int n = readNumber(string("  ") + T(M_DELETE_WHICH), 0, static_cast<int>(e.size()));
    if (n == 0) { cout << "  " << T(M_CANCELLED) << endl; return; }

    cout << "  -> " << e[n - 1].servicio << " | " << e[n - 1].usuario << endl;
    if (!readYesNo(string("  ") + T(M_DELETE_CONFIRM))) { cout << "  " << T(M_CANCELLED) << endl; return; }

    Entrada removed = e[n - 1];
    e.erase(e.begin() + (n - 1));
    if (v.save()) cout << "  " << T(M_ENTRY_DELETED) << endl;
    else { e.insert(e.begin() + (n - 1), removed); cout << "  [!] " << T(M_ERR_SAVE) << endl; }
    secureWipe(removed.contrasena);
}

// [HU12 - Sprint 3] Generar contraseña desde el menú (Camilly Aoki)
static void actionGenerate() {
    printTitle(T(M_MENU_GEN));
    string p = generatorDialog();
    cout << "\n  " << T(M_GEN_RESULT) << p << endl;
    secureWipe(p);
}

// =============================================================================
//  Bucle principal
//  [HU14 - Sprint 3] Bloquear la bóveda sin cerrar el programa (Davor Blaz)
// =============================================================================
int runApp() {
    chooseLanguage();
    printBanner();

    Boveda boveda(VAULT_FILE);
    if (!boveda.exists()) {
        if (!createMasterPassword(boveda)) return 1;
    } else {
        if (!unlockVault(boveda)) return 1;
    }

    for (;;) {
        if (boveda.isUnlocked()) {
            switch (mainMenu(boveda.entradas().size())) {
            case 1: actionAdd(boveda); break;
            case 2: actionList(boveda); break;
            case 3: actionSearch(boveda); break;
            case 4: actionEdit(boveda); break;
            case 5: actionDelete(boveda); break;
            case 6: actionGenerate(); break;
            case 7: chooseLanguage(); cout << "  " << T(M_LANG_CHANGED) << endl; break;
            case 8: boveda.lock(); cout << "  " << T(M_LOCKED) << endl; break;
            case 0: boveda.lock(); cout << "\n  " << T(M_BYE) << endl; return 0;
            }
        } else {
            switch (lockedMenu()) {
            case 1: if (!unlockVault(boveda)) return 1; break;
            case 2: chooseLanguage(); cout << "  " << T(M_LANG_CHANGED) << endl; break;
            case 0: cout << "\n  " << T(M_BYE) << endl; return 0;
            }
        }
    }
}
