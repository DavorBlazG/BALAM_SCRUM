// =============================================================================
//  crypto.hpp - Primitivas criptográficas de BALAM
//
//  [HU3 - Sprint 1] Sal aleatoria y verificador de la contraseña maestra (Davor Blaz)
//  [HU4 - Sprint 1] Comparación segura del verificador (Camilly Aoki)
//  [HU7 - Sprint 2] Derivar la clave (PBKDF2) y cifrar con AES-256 (Camilly Aoki)
//  [HU12 - Sprint 3] Aleatoriedad segura para el generador (Camilly Aoki)
// =============================================================================
#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

typedef std::vector<uint8_t> Bytes;

// ---- Utilidades de memoria ---------------------------------------------------
void secureWipe(void* p, size_t n);          // borra memoria sin que se optimice
void secureWipe(std::string& s);
void secureWipe(Bytes& b);
bool constantTimeEqual(const uint8_t* a, const uint8_t* b, size_t n);

// ---- Aleatoriedad criptográficamente segura ----------------------------------
// Windows: BCryptGenRandom. Linux/macOS: /dev/urandom.
// Lanza std::runtime_error("RNG") si el sistema no puede dar aleatoriedad.
void     secureRandom(uint8_t* buf, size_t n);
uint32_t randomBelow(uint32_t n);            // uniforme en [0, n), sin sesgo

// ---- SHA-256 -----------------------------------------------------------------
class Sha256 {
public:
    Sha256();
    void reset();
    void update(const uint8_t* data, size_t len);
    void final(uint8_t out[32]);

private:
    uint32_t h[8];
    uint8_t  buf[64];
    size_t   bufLen;
    uint64_t totalLen;

    void compress(const uint8_t block[64]);
};

// ---- HMAC-SHA256 -------------------------------------------------------------
class HmacSha256 {
public:
    HmacSha256(const uint8_t* key, size_t keyLen);
    void update(const uint8_t* data, size_t len);
    void final(uint8_t out[32]);

private:
    Sha256 inner, outer;
};

void hmacSha256(const uint8_t* key, size_t keyLen, const uint8_t* data, size_t len, uint8_t out[32]);

// ---- PBKDF2-HMAC-SHA256 (salida de 32 bytes) ---------------------------------
void pbkdf2Sha256(const std::string& password, const uint8_t* salt, size_t saltLen,
                  uint32_t iterations, uint8_t out[32]);

// ---- AES-256 (cifrado de bloque + modo CTR) ----------------------------------
class Aes256 {
public:
    explicit Aes256(const uint8_t key[32]);
    ~Aes256();

    void encryptBlock(const uint8_t in[16], uint8_t out[16]) const;
    // CTR: cifrar y descifrar son la misma operación.
    void ctr(const uint8_t iv[16], const uint8_t* in, uint8_t* out, size_t len) const;

private:
    uint8_t roundKeys[240];

    static uint8_t SBOX[256];
    static bool    tablesReady;
    static void    initTables();

    void expandKey(const uint8_t key[32]);
    void addRoundKey(uint8_t s[16], int round) const;
    static void subBytes(uint8_t s[16]);
    static void shiftRows(uint8_t s[16]);
    static void mixColumns(uint8_t s[16]);
};

// ---- Generador de contraseñas (HU12) -----------------------------------------
// Devuelve "" si no se ha elegido ningún tipo de carácter.
std::string generatePassword(int length, bool lower, bool upper, bool digits, bool symbols);
