// =============================================================================
//  auth.hpp - Autenticación con la contraseña maestra
//
//  [HU3 - Sprint 1] Crear la contraseña maestra (Davor Blaz)
//  [HU4 - Sprint 1] Verificar la contraseña maestra (Camilly Aoki)
//  [HU14 - Sprint 3] Volver a pedirla al desbloquear (Davor Blaz)
// =============================================================================
#pragma once

class Boveda;

// Pide la contraseña maestra dos veces y crea la bóveda. false si falla.
bool createMasterPassword(Boveda& v);

// Pide la contraseña maestra (máx. 3 intentos). false si no se puede entrar.
bool unlockVault(Boveda& v);
