// =============================================================================
//  crypto.cpp - Implementación de SHA-256, HMAC, PBKDF2, AES-256-CTR,
//               aleatoriedad segura y generador de contraseñas.
// =============================================================================
#include "crypto.hpp"

#ifdef _WIN32
#  ifndef NOMINMAX
#    define NOMINMAX
#  endif
#  include <windows.h>
#  include <bcrypt.h>
#  pragma comment(lib, "bcrypt.lib")
#else
#  include <fstream>
#endif

#include <algorithm>
#include <cstring>
#include <stdexcept>

using namespace std;

// =============================================================================
//  Utilidades de memoria
// =============================================================================
void secureWipe(void* p, size_t n) {
    volatile uint8_t* v = static_cast<volatile uint8_t*>(p);
    while (n--) *v++ = 0;
}

void secureWipe(string& s) {
    if (!s.empty()) secureWipe(&s[0], s.size());
    s.clear();
}

void secureWipe(Bytes& b) {
    if (!b.empty()) secureWipe(b.data(), b.size());
    b.clear();
}

// Comparación en tiempo constante (evita ataques de temporización).
bool constantTimeEqual(const uint8_t* a, const uint8_t* b, size_t n) {
    uint8_t diff = 0;
    for (size_t i = 0; i < n; ++i) diff |= static_cast<uint8_t>(a[i] ^ b[i]);
    return diff == 0;
}

// =============================================================================
//  Aleatoriedad criptográficamente segura
//  [HU3 - Sprint 1] Sal de la contraseña maestra (Davor Blaz)
//  [HU12 - Sprint 3] Generador de contraseñas (Camilly Aoki)
// =============================================================================
void secureRandom(uint8_t* buf, size_t n) {
#ifdef _WIN32
    NTSTATUS st = BCryptGenRandom(NULL, buf, static_cast<ULONG>(n), BCRYPT_USE_SYSTEM_PREFERRED_RNG);
    if (!BCRYPT_SUCCESS(st)) throw runtime_error("RNG");
#else
    ifstream f("/dev/urandom", ios::binary);
    if (!f || !f.read(reinterpret_cast<char*>(buf), static_cast<streamsize>(n)))
        throw runtime_error("RNG");
#endif
}

// Muestreo por rechazo: evita el sesgo de hacer "r % n" directamente.
uint32_t randomBelow(uint32_t n) {
    if (n <= 1) return 0;
    const uint32_t limit = 0xFFFFFFFFu - (0xFFFFFFFFu % n);
    uint32_t r;
    do {
        uint8_t b[4];
        secureRandom(b, 4);
        r = (uint32_t)b[0] | ((uint32_t)b[1] << 8) | ((uint32_t)b[2] << 16) | ((uint32_t)b[3] << 24);
    } while (r >= limit);
    return r % n;
}

// =============================================================================
//  SHA-256 (FIPS 180-4)
//  [HU3/HU4 - Sprint 1] Verificador de la contraseña maestra (Davor / Camilly)
// =============================================================================
static uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

Sha256::Sha256() { reset(); }

void Sha256::reset() {
    static const uint32_t H0[8] = {
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19 };
    memcpy(h, H0, sizeof(h));
    bufLen = 0;
    totalLen = 0;
}

void Sha256::update(const uint8_t* data, size_t len) {
    totalLen += len;
    while (len > 0) {
        size_t take = min(len, (size_t)64 - bufLen);
        memcpy(buf + bufLen, data, take);
        bufLen += take; data += take; len -= take;
        if (bufLen == 64) { compress(buf); bufLen = 0; }
    }
}

void Sha256::final(uint8_t out[32]) {
    uint64_t bits = totalLen * 8;
    uint8_t pad = 0x80;
    update(&pad, 1);
    uint8_t zero = 0;
    while (bufLen != 56) update(&zero, 1);
    uint8_t lenBytes[8];
    for (int i = 0; i < 8; ++i) lenBytes[i] = (uint8_t)(bits >> (56 - 8 * i));
    update(lenBytes, 8);
    for (int i = 0; i < 8; ++i) {
        out[4 * i]     = (uint8_t)(h[i] >> 24);
        out[4 * i + 1] = (uint8_t)(h[i] >> 16);
        out[4 * i + 2] = (uint8_t)(h[i] >> 8);
        out[4 * i + 3] = (uint8_t)(h[i]);
    }
    secureWipe(buf, sizeof(buf));
}

void Sha256::compress(const uint8_t block[64]) {
    static const uint32_t K[64] = {
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2 };
    uint32_t w[64];
    for (int i = 0; i < 16; ++i)
        w[i] = ((uint32_t)block[4 * i] << 24) | ((uint32_t)block[4 * i + 1] << 16) |
               ((uint32_t)block[4 * i + 2] << 8) | (uint32_t)block[4 * i + 3];
    for (int i = 16; i < 64; ++i) {
        uint32_t s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
    for (int i = 0; i < 64; ++i) {
        uint32_t S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        uint32_t ch = (e & f) ^ (~e & g);
        uint32_t t1 = hh + S1 + ch + K[i] + w[i];
        uint32_t S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        uint32_t mj = (a & b) ^ (a & c) ^ (b & c);
        uint32_t t2 = S0 + mj;
        hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
}

// =============================================================================
//  HMAC-SHA256 (RFC 2104) y PBKDF2 (RFC 8018)
//  [HU7 - Sprint 2] Derivar la clave de cifrado a partir de la contraseña
//                   maestra (Camilly Aoki)
// =============================================================================
HmacSha256::HmacSha256(const uint8_t* key, size_t keyLen) {
    uint8_t k[64] = { 0 };
    if (keyLen > 64) { Sha256 s; s.update(key, keyLen); s.final(k); }
    else memcpy(k, key, keyLen);
    uint8_t ipad[64], opad[64];
    for (int i = 0; i < 64; ++i) { ipad[i] = k[i] ^ 0x36; opad[i] = k[i] ^ 0x5c; }
    inner.update(ipad, 64);
    outer.update(opad, 64);
    secureWipe(k, 64); secureWipe(ipad, 64); secureWipe(opad, 64);
}

void HmacSha256::update(const uint8_t* data, size_t len) { inner.update(data, len); }

void HmacSha256::final(uint8_t out[32]) {
    uint8_t ih[32];
    inner.final(ih);
    outer.update(ih, 32);
    outer.final(out);
    secureWipe(ih, 32);
}

void hmacSha256(const uint8_t* key, size_t keyLen, const uint8_t* data, size_t len, uint8_t out[32]) {
    HmacSha256 m(key, keyLen);
    m.update(data, len);
    m.final(out);
}

void pbkdf2Sha256(const string& password, const uint8_t* salt, size_t saltLen,
                  uint32_t iterations, uint8_t out[32]) {
    const uint8_t* pw = reinterpret_cast<const uint8_t*>(password.data());
    HmacSha256 base(pw, password.size());   // estado precalculado (más rápido)

    uint8_t u[32], t[32];
    HmacSha256 first = base;
    first.update(salt, saltLen);
    const uint8_t blockIndex[4] = { 0, 0, 0, 1 };
    first.update(blockIndex, 4);
    first.final(u);
    memcpy(t, u, 32);

    for (uint32_t i = 1; i < iterations; ++i) {
        HmacSha256 m = base;
        m.update(u, 32);
        m.final(u);
        for (int j = 0; j < 32; ++j) t[j] ^= u[j];
    }
    memcpy(out, t, 32);
    secureWipe(u, 32); secureWipe(t, 32);
}

// =============================================================================
//  AES-256 (FIPS-197) en modo CTR
//  [HU7 - Sprint 2] Cifrar y descifrar las entradas con AES (Camilly Aoki)
// =============================================================================
uint8_t Aes256::SBOX[256];
bool    Aes256::tablesReady = false;

static uint8_t rotl8(uint8_t x, int s) { return (uint8_t)((x << s) | (x >> (8 - s))); }
static uint8_t xtime(uint8_t x) { return (uint8_t)((x << 1) ^ ((x & 0x80) ? 0x1b : 0)); }

// Genera la S-box de AES (inverso en GF(2^8) + transformación afín).
void Aes256::initTables() {
    if (tablesReady) return;
    uint8_t p = 1, q = 1;
    do {
        p = (uint8_t)(p ^ (p << 1) ^ ((p & 0x80) ? 0x1b : 0));
        q ^= (uint8_t)(q << 1);
        q ^= (uint8_t)(q << 2);
        q ^= (uint8_t)(q << 4);
        if (q & 0x80) q ^= 0x09;
        uint8_t x = (uint8_t)(q ^ rotl8(q, 1) ^ rotl8(q, 2) ^ rotl8(q, 3) ^ rotl8(q, 4));
        SBOX[p] = (uint8_t)(x ^ 0x63);
    } while (p != 1);
    SBOX[0] = 0x63;
    tablesReady = true;
}

Aes256::Aes256(const uint8_t key[32]) {
    initTables();
    expandKey(key);
}

Aes256::~Aes256() { secureWipe(roundKeys, sizeof(roundKeys)); }

void Aes256::expandKey(const uint8_t key[32]) {
    memcpy(roundKeys, key, 32);
    uint8_t rcon = 1;
    for (int i = 8; i < 60; ++i) {
        uint8_t t[4];
        memcpy(t, roundKeys + 4 * (i - 1), 4);
        if (i % 8 == 0) {
            uint8_t tmp = t[0];
            t[0] = (uint8_t)(SBOX[t[1]] ^ rcon);
            t[1] = SBOX[t[2]];
            t[2] = SBOX[t[3]];
            t[3] = SBOX[tmp];
            rcon = xtime(rcon);
        } else if (i % 8 == 4) {
            for (int j = 0; j < 4; ++j) t[j] = SBOX[t[j]];
        }
        for (int j = 0; j < 4; ++j) roundKeys[4 * i + j] = roundKeys[4 * (i - 8) + j] ^ t[j];
    }
}

void Aes256::addRoundKey(uint8_t s[16], int round) const {
    for (int i = 0; i < 16; ++i) s[i] ^= roundKeys[16 * round + i];
}

void Aes256::subBytes(uint8_t s[16]) {
    for (int i = 0; i < 16; ++i) s[i] = SBOX[s[i]];
}

void Aes256::shiftRows(uint8_t s[16]) {
    uint8_t t[16];
    for (int c = 0; c < 4; ++c)
        for (int r = 0; r < 4; ++r)
            t[4 * c + r] = s[4 * ((c + r) % 4) + r];
    memcpy(s, t, 16);
}

void Aes256::mixColumns(uint8_t s[16]) {
    for (int c = 0; c < 4; ++c) {
        uint8_t* col = s + 4 * c;
        uint8_t a0 = col[0], a1 = col[1], a2 = col[2], a3 = col[3];
        uint8_t all = (uint8_t)(a0 ^ a1 ^ a2 ^ a3);
        col[0] ^= (uint8_t)(all ^ xtime((uint8_t)(a0 ^ a1)));
        col[1] ^= (uint8_t)(all ^ xtime((uint8_t)(a1 ^ a2)));
        col[2] ^= (uint8_t)(all ^ xtime((uint8_t)(a2 ^ a3)));
        col[3] ^= (uint8_t)(all ^ xtime((uint8_t)(a3 ^ a0)));
    }
}

void Aes256::encryptBlock(const uint8_t in[16], uint8_t out[16]) const {
    uint8_t s[16];
    memcpy(s, in, 16);
    addRoundKey(s, 0);
    for (int round = 1; round < 14; ++round) {
        subBytes(s); shiftRows(s); mixColumns(s); addRoundKey(s, round);
    }
    subBytes(s); shiftRows(s); addRoundKey(s, 14);
    memcpy(out, s, 16);
    secureWipe(s, 16);
}

void Aes256::ctr(const uint8_t iv[16], const uint8_t* in, uint8_t* out, size_t len) const {
    uint8_t counter[16], stream[16];
    memcpy(counter, iv, 16);
    for (size_t pos = 0; pos < len; pos += 16) {
        encryptBlock(counter, stream);
        size_t n = min((size_t)16, len - pos);
        for (size_t i = 0; i < n; ++i) out[pos + i] = in[pos + i] ^ stream[i];
        for (int i = 15; i >= 0; --i) if (++counter[i] != 0) break;  // contador big-endian
    }
    secureWipe(stream, 16);
}

// =============================================================================
//  Generador de contraseñas
//  [HU12 - Sprint 3] Generador aleatorio y seguro (Camilly Aoki)
//                    Longitud y tipos de caracteres configurables (Camilly Aoki)
// =============================================================================
string generatePassword(int length, bool lower, bool upper, bool digits, bool symbols) {
    static const string LOWER = "abcdefghijklmnopqrstuvwxyz";
    static const string UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static const string DIGIT = "0123456789";
    static const string SYMBOL = "!@#$%^&*()-_=+[]{};:,.?/";

    vector<const string*> sets;
    if (lower)   sets.push_back(&LOWER);
    if (upper)   sets.push_back(&UPPER);
    if (digits)  sets.push_back(&DIGIT);
    if (symbols) sets.push_back(&SYMBOL);
    if (sets.empty() || length < static_cast<int>(sets.size())) return "";

    string all;
    for (size_t i = 0; i < sets.size(); ++i) all += *sets[i];

    string pwd;
    // Garantiza al menos un carácter de cada tipo elegido
    for (size_t i = 0; i < sets.size(); ++i)
        pwd += (*sets[i])[randomBelow(static_cast<uint32_t>(sets[i]->size()))];
    while (static_cast<int>(pwd.size()) < length)
        pwd += all[randomBelow(static_cast<uint32_t>(all.size()))];
    // Mezcla Fisher-Yates con aleatoriedad segura
    for (size_t i = pwd.size() - 1; i > 0; --i)
        swap(pwd[i], pwd[randomBelow(static_cast<uint32_t>(i + 1))]);
    return pwd;
}
