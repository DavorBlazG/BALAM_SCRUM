// =============================================================================
//  auth.cpp - Crear y verificar la contraseña maestra
// =============================================================================
#include "auth.hpp"
#include "console.hpp"
#include "crypto.hpp"
#include "i18n.hpp"
#include "vault.hpp"

#include <chrono>
#include <iostream>
#include <thread>

using namespace std;

static const size_t MIN_MASTER_LEN  = 8;
static const int    MAX_LOGIN_TRIES = 3;

// [HU3 - Sprint 1] Crear la contraseña maestra con confirmación
bool createMasterPassword(Boveda& v) {
    printTitle(T(M_NEW_VAULT));
    cout << "  " << T(M_MASTER_RULES) << endl;
    for (;;) {
        string p1 = readHidden(string("  ") + T(M_MASTER_NEW));
        if (p1.size() < MIN_MASTER_LEN) {
            cout << "  [!] " << T(M_MASTER_TOO_SHORT) << endl;
            secureWipe(p1);
            continue;
        }
        string p2 = readHidden(string("  ") + T(M_MASTER_CONFIRM));
        if (p1 != p2) {
            cout << "  [!] " << T(M_MASTER_MISMATCH) << endl;
            secureWipe(p1); secureWipe(p2);
            continue;
        }
        cout << "  " << T(M_PROCESSING) << endl;
        Boveda::Result r = v.create(p1);
        secureWipe(p1); secureWipe(p2);
        if (r != Boveda::OK) { cout << "  [!] " << T(M_ERR_SAVE) << endl; return false; }
        cout << "  " << T(M_MASTER_CREATED) << endl;
        return true;
    }
}

// [HU4 - Sprint 1] Verificar la contraseña maestra (máx. 3 intentos)
bool unlockVault(Boveda& v) {
    for (int attempt = 1; attempt <= MAX_LOGIN_TRIES; ++attempt) {
        string pass = readHidden(string("  ") + T(M_MASTER_ENTER));
        cout << "  " << T(M_PROCESSING) << endl;
        Boveda::Result r = v.unlock(pass);
        secureWipe(pass);
        switch (r) {
        case Boveda::OK:
            cout << "  " << T(M_UNLOCKED) << endl;
            return true;
        case Boveda::WRONG_PASSWORD:
            this_thread::sleep_for(chrono::milliseconds(800));   // frena ataques de fuerza bruta
            if (attempt < MAX_LOGIN_TRIES)
                cout << "  [!] " << T(M_MASTER_WRONG) << (MAX_LOGIN_TRIES - attempt) << endl;
            break;
        case Boveda::CORRUPT:
            cout << "  [!] " << T(M_ERR_CORRUPT) << endl;
            return false;
        case Boveda::IO_ERROR:
            cout << "  [!] " << T(M_ERR_READ) << endl;
            return false;
        }
    }
    cout << "  [!] " << T(M_TOO_MANY_TRIES) << endl;
    return false;
}
