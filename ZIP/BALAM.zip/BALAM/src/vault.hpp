// =============================================================================
//  vault.hpp - Bóveda cifrada de BALAM
//
//  [HU3 - Sprint 1] Crear la contraseña maestra (Davor Blaz)
//  [HU4 - Sprint 1] Verificar la contraseña maestra (Camilly Aoki)
//  [HU6 - Sprint 2] Estructura Entrada y formato del archivo (Davor Blaz)
//  [HU7 - Sprint 2] Guardar y cargar la bóveda cifrada (Davor Blaz)
//  [HU10/HU11 - Sprint 3] Guardar cambios tras modificar/eliminar (Davor / Gerard)
//  [HU13 - Sprint 3] Escritura atómica y errores de lectura (Gerard Conesa)
//  [HU14 - Sprint 3] Bloqueo de la bóveda (Davor Blaz)
//
//  Formato de balam.dat (binario):
//    "BALAM" + versión(1) | sal(16) | iteraciones(4) | verificador(32)
//    IV(16) | longitud(4) | datos cifrados AES-256-CTR | HMAC-SHA256(32)
//  El HMAC cubre todo lo anterior: si alguien cambia un byte, se detecta.
// =============================================================================
#pragma once

#include "crypto.hpp"

#include <array>
#include <cstdint>
#include <string>
#include <vector>

const uint32_t PBKDF2_ITERATIONS = 100000;   // coste de derivación de la clave

struct Entrada {
    std::string servicio;
    std::string usuario;
    std::string contrasena;
};

class Boveda {
public:
    enum Result { OK, WRONG_PASSWORD, CORRUPT, IO_ERROR };

    explicit Boveda(const std::string& filePath);
    ~Boveda();

    bool exists() const;
    bool isUnlocked() const { return unlocked; }
    std::vector<Entrada>& entradas() { return items; }

    Result create(const std::string& master);   // HU3: nueva bóveda
    Result unlock(const std::string& master);   // HU4 + HU7: verificar y descifrar
    bool   save();                              // HU7: cifrar y guardar
    void   lock();                              // HU14: borrar claves y datos de memoria

private:
    std::string path;
    std::array<uint8_t, 16> salt;
    uint32_t iterations;
    std::array<uint8_t, 32> verifier;
    std::array<uint8_t, 32> encKey;
    std::array<uint8_t, 32> macKey;
    std::vector<Entrada> items;
    bool unlocked;

    void deriveKeys(const std::string& master, uint8_t outVerifier[32]);
    void wipeKeys();

    static Bytes serialize(const std::vector<Entrada>& v);
    static bool  deserialize(const Bytes& b, std::vector<Entrada>& out);
    bool readFile(Bytes& out) const;
    bool writeFileAtomic(const Bytes& data) const;
};
