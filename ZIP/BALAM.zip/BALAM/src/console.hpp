// =============================================================================
//  console.hpp - Entrada/salida por consola y validación de datos
//
//  [HU1 - Sprint 1] Diseño de la consola (Davor Blaz)
//  [HU5 - Sprint 1] Avisos ante opciones incorrectas (Camilly Aoki)
//  [HU6 - Sprint 2] Validar los datos de una nueva entrada (Gerard Conesa)
//  [HU13 - Sprint 3] Control de entradas incorrectas sin cerrarse (Gerard Conesa)
// =============================================================================
#pragma once

#include <string>

// Se lanza si se cierra la entrada estándar (Ctrl+Z / Ctrl+D / Ctrl+C).
struct InputClosed {};

void setupConsole();                       // UTF-8 en la consola de Windows
void printTitle(const std::string& title);

std::string trim(const std::string& s);
std::string toLower(std::string s);
bool        parseInt(const std::string& text, long& value);

std::string readLine();
std::string prompt(const std::string& text);
std::string readHidden(const std::string& text);            // no muestra lo escrito

int         readMenuOption(int minOpt, int maxOpt);         // repite hasta opción válida
int         readNumber(const std::string& text, int minV, int maxV, int defaultV = -1);
bool        readYesNo(const std::string& question);
std::string readNonEmpty(const std::string& label);
std::string readNonEmptyHidden(const std::string& label);
