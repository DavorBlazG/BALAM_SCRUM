// =============================================================================
//  app.hpp - Aplicación BALAM: menús y acciones del usuario
//
//  [HU1 - Sprint 1] Menú principal (Davor Blaz)
//  [HU6, HU8, HU9 - Sprint 2] Añadir, ver y buscar entradas
//  [HU10, HU11, HU12, HU14 - Sprint 3] Modificar, eliminar, generar y bloquear
// =============================================================================
#pragma once

// Ejecuta BALAM. Devuelve el código de salida del programa.
int runApp();
