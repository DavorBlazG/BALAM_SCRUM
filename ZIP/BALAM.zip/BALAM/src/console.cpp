// =============================================================================
//  console.cpp - Entrada/salida por consola y validación de datos
// =============================================================================
#include "console.hpp"
#include "i18n.hpp"

#ifdef _WIN32
#  ifndef NOMINMAX
#    define NOMINMAX
#  endif
#  include <windows.h>
#  include <conio.h>
#else
#  include <termios.h>
#  include <unistd.h>
#endif

#include <cctype>
#include <cstdlib>
#include <iostream>

using namespace std;

void setupConsole() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
}

void printTitle(const string& title) {
    cout << "\n  ------------------------------------------------\n"
         << "   " << title << "\n"
         << "  ------------------------------------------------\n";
}

string trim(const string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}

string toLower(string s) {
    for (size_t i = 0; i < s.size(); ++i) s[i] = static_cast<char>(tolower(static_cast<unsigned char>(s[i])));
    return s;
}

// Solo acepta dígitos (rechaza "3a", "-1", " ", etc.).
bool parseInt(const string& text, long& value) {
    string t = trim(text);
    if (t.empty() || t.size() > 9) return false;
    for (size_t i = 0; i < t.size(); ++i)
        if (!isdigit(static_cast<unsigned char>(t[i]))) return false;
    value = strtol(t.c_str(), NULL, 10);
    return true;
}

string readLine() {
    string s;
    if (!getline(cin, s)) throw InputClosed();
    if (!s.empty() && s.back() == '\r') s.pop_back();
    return s;
}

string prompt(const string& text) {
    cout << text << flush;
    return readLine();
}

// [HU3/HU4] Lectura de contraseñas sin mostrarlas por pantalla.
string readHidden(const string& text) {
    cout << text << flush;
    string s;
#ifdef _WIN32
    for (;;) {
        int c = _getch();
        if (c == '\r' || c == '\n') break;
        if (c == 3 || c == 26) throw InputClosed();              // Ctrl+C / Ctrl+Z
        if (c == 0 || c == 224) { _getch(); continue; }          // teclas especiales
        if (c == '\b') {
            if (!s.empty()) { s.pop_back(); cout << "\b \b" << flush; }
            continue;
        }
        s.push_back(static_cast<char>(c));
        cout << '*' << flush;
    }
    cout << endl;
#else
    termios oldt;
    bool tty = isatty(STDIN_FILENO) && tcgetattr(STDIN_FILENO, &oldt) == 0;
    if (tty) {
        termios newt = oldt;
        newt.c_lflag &= ~ECHO;
        tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    }
    bool ok = static_cast<bool>(getline(cin, s));
    if (tty) { tcsetattr(STDIN_FILENO, TCSANOW, &oldt); cout << endl; }
    if (!ok) throw InputClosed();
    if (!s.empty() && s.back() == '\r') s.pop_back();
#endif
    return s;
}

// [HU5] Opción de menú: repite hasta que sea válida.
int readMenuOption(int minOpt, int maxOpt) {
    for (;;) {
        long v;
        if (parseInt(prompt(string("  ") + T(M_OPTION)), v) && v >= minOpt && v <= maxOpt)
            return static_cast<int>(v);
        cout << "  [!] " << T(M_INVALID_OPTION) << endl;
    }
}

// Número en un rango; si se pulsa Intro y hay valor por defecto, lo usa.
int readNumber(const string& text, int minV, int maxV, int defaultV) {
    for (;;) {
        string line = trim(prompt(text));
        if (line.empty() && defaultV >= 0) return defaultV;
        long v;
        if (parseInt(line, v) && v >= minV && v <= maxV) return static_cast<int>(v);
        cout << "  [!] " << T(M_RANGE_A) << minV << T(M_RANGE_AND) << maxV << "." << endl;
    }
}

// Acepta la letra de "sí" del idioma actual (s / s / y / j), 'y' y 'n'.
bool readYesNo(const string& question) {
    const char yes = T(M_YES_CHAR)[0];
    for (;;) {
        string a = trim(prompt(question + T(M_YES_NO)));
        if (a.size() == 1) {
            char c = static_cast<char>(tolower(static_cast<unsigned char>(a[0])));
            if (c == yes || c == 'y') return true;
            if (c == 'n') return false;
        }
        cout << "  [!] " << T(M_INVALID_OPTION) << endl;
    }
}

// [HU6] No se permiten campos vacíos.
string readNonEmpty(const string& label) {
    for (;;) {
        string v = trim(prompt("  " + label + ": "));
        if (!v.empty()) return v;
        cout << "  [!] " << T(M_FIELD_EMPTY) << endl;
    }
}

string readNonEmptyHidden(const string& label) {
    for (;;) {
        string v = readHidden("  " + label + ": ");
        if (!trim(v).empty()) return v;
        cout << "  [!] " << T(M_FIELD_EMPTY) << endl;
    }
}
